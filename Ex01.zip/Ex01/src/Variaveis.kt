fun main() {
    // 1. Criação de Variáveis
    val idadePessoa: Int = 19 // Idade de uma pessoa
    val alturaPessoa: Double = 1.70 // Altura em metros
    val nomePessoa: String = "Gustavo" // Nome da pessoa
    val eEstudante: Boolean = true // Indicação de se a pessoa é estudante

    // 2. Atribuição de Valores
    // Os valores já foram atribuídos ao declarar as variáveis acima

    // 3. Operações Simples
    // Soma de duas idades
    val idadeOutraPessoa: Int = 30
    val somaIdades: Int = idadePessoa + idadeOutraPessoa

    // Multiplicação da altura por um fator de 2
    val alturaDuplicada: Double = alturaPessoa * 2

    // Concatenação do nome com uma saudação
    val saudacao: String = "Olá, $nomePessoa!"

    // 4. Exibição de Resultados
    println("Idade da pessoa: $idadePessoa")
    println("Altura da pessoa: $alturaPessoa metros")
    println("Nome da pessoa: $nomePessoa")
    println("É estudante? $eEstudante")
    println("Soma de idades: $somaIdades")
    println("Altura duplicada: $alturaDuplicada metros")
    println("Saudação: $saudacao")
}
